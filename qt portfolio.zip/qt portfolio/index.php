<?php include 'incl/header.php'; ?>
<main class="page__wrap">

    <div class="pfolio-sec sec-space">
        <div class="container">
            <div class="pfolio-inner">
                <div class="sec-title">
                    <div class="wm-heading">
                        <h1>showcase</h1>
                        <div class="section-heading">
                            <h4>Portfolio</h4>
                        </div><!--/.section-heading-->
                    </div><!--/.section-heading-->
                </div><!--/.sec-title-->

                <div class="folio-content">
                    <div class="sm-container">
                        <p>
                            Quaid Technologies is Offering Branding, SEO Services, Web Development and Mobile App Development
                            solutions which move the boundaries. Our Sophisticated approach to the development of digital
                            experiences exceeds all expectations.
                        </p>
                    </div>
                </div>

                <div class="pfolio-tabs-sec">
                    <div class="container">
                        <div class="tabs-inner">
                                <div class="sm-container">
                                    <nav>
                                        <div class="nav nav-tabs tab-btn" id="nav-tab" role="tablist">
                                            <a class="nav-link active" id="nav-home-tab" data-toggle="tab" href="#tab1" role="tab" aria-controls="nav-home" aria-selected="true">Branding</a>
                                            <a class="nav-link" id="nav-profile-tab" data-toggle="tab" href="#tab2" role="tab" aria-controls="nav-profile" aria-selected="false">SEO Services</a>
                                            <a class="nav-link" id="nav-contact-tab" data-toggle="tab" href="#tab3" role="tab" aria-controls="nav-contact" aria-selected="false">Web Development</a>
                                            <a class="nav-link" id="nav-contact-tab" data-toggle="tab" href="#tab4" role="tab" aria-controls="nav-contact" aria-selected="false">App Development</a>
                                        </div>
                                    </nav>
                                </div><!--/.sm-container-->
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="tab1" role="tabpanel" aria-labelledby="nav-home-tab">

                                    <div class="row">
                                        
                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/thriggle.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/silicon.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/thriggle.png" alt="">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/thriggle.png" alt="">
                                            </div>
                                        </div>


                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/thriggle.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/silicon.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/thriggle.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/silicon.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/thriggle.png" alt="">
                                            </div>
                                        </div>

                                    </div><!--/.row-->

                                </div>
                                <div class="tab-pane fade" id="tab2" role="tabpanel" aria-labelledby="nav-profile-tab">
                                    <div class="row">

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/seo1.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/seo2.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/seo3.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/seo1.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/seo2.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/seo3.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/seo1.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/seo2.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/seo3.png" alt="">
                                            </div>
                                        </div>

                                    </div><!--/.row-->
                                </div>
                                <div class="tab-pane fade" id="tab3" role="tabpanel" aria-labelledby="nav-contact-tab">
                                    <div class="row">

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/web1.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/web2.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/web1.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/web1.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/web2.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/web1.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/web1.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/web2.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/web1.png" alt="">
                                            </div>
                                        </div>

                                    </div><!--/.row-->
                                </div>
                                <div class="tab-pane fade" id="tab4" role="tabpanel" aria-labelledby="nav-contact-tab">
                                    <div class="row">

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/app1.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/app1.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/app1.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/app1.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/app1.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/app1.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/app1.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/app1.png" alt="">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="tab-col">
                                                <img src="assets/img/app1.png" alt="">
                                            </div>
                                        </div>

                                    </div><!--/.row-->

                                </div>
                            </div>

                            <div class="load-more-btn">
                                <a href="#">Load More...</a>
                            </div><!--/.load-more-btn-->

                        </div><!--/.tabs-inner-->

                    </div><!--/.container-->
                </div><!--/.pfolio-tabs-sec-->

            </div><!--/.pfolio-inner-->
        </div><!--/.container-->
    </div><!--/.pfolio-sec-->
    <div class="folio-stat-sec">
        <div class="sm-container">
                <div class="folio-stat-inner" data-bg="assets/img/folio-stmnt.png"">
                    <div class="stmnt-content">
                        <p>We are an innovative and leading IT company and full-service digital agency</p>
                    </div>

                    <div class="contact-btn">
                        <a href="#" class="btn-white">Contact</a>
                    </div>

                </div><!--/.folio-stat-inner-->
        </div><!--/.sm-container-->
    </div><!--/.folio-stat-sec-->



</main><!--/.page__wrap-->

<?php include 'incl/footer.php'; ?>
