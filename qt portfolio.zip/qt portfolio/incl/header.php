<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no, user-scalable=no">

    <title>QT Portfolio</title>

    <link href="assets/img/favicon/apple-touch-icon.png" rel="apple-touch-icon" type="image/png" sizes="180x180">
    <link href="assets/img/favicon/favicon-32x32.png" rel="icon" type="image/png" sizes="32x32">
    <link href="assets/img/favicon/favicon-16x16.png" rel="icon" type="image/png" sizes="16x16">
    <link href="assets/img/favicon/manifest.json" rel="manifest">
    <link href="assets/img/favicon/favicon.ico" rel="shortcut icon">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200;300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        .site__wrapper {
            opacity: 0;
            -ms-filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);
            filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);
        }
    </style>
    <link rel="stylesheet" href="assets/css/theme.css">

</head>

<body class="preload">

<div class="preload__wrap"></div>

<div class="site__wrapper">

